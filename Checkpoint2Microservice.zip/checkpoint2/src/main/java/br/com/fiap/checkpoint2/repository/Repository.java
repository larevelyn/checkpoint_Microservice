package br.com.fiap.checkpoint2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.fiap.checkpoint2.models.Pedidos;

public interface Repository extends JpaRepository<Pedidos, Integer>{

}
