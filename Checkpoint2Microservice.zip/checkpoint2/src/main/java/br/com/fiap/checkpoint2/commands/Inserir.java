package br.com.fiap.checkpoint2.commands;

import java.time.Instant;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.fiap.checkpoint2.dto.PedidosDTO;
import br.com.fiap.checkpoint2.mapper.MapperPedido;
import br.com.fiap.checkpoint2.models.Pedidos;
import br.com.fiap.checkpoint2.repository.Repository;
import lombok.Builder;

@Service
public class Inserir {
	@Autowired
    Repository repository;

    @Autowired
    MapperPedido mapper;

    public PedidosDTO create(PedidosDTO pedido) {
        Pedidos savePedido = Pedidos.builder()
                .codigoCliente(pedido.getCodigoCliente())
                .dataPedido(Instant.now())
                .valorTotal(pedido.getValorTotal())
                .dataCadastro(Instant.now())
                .build();

        repository.save(savePedido);

        return mapper.toDto(savePedido);
    }

    public boolean delete(Integer id) {
        Optional<Pedidos> found = repository.findById(id);

        if (found.isEmpty()) {
            return false;
        }

        repository.deleteById(id);
        return true;
    }

    public PedidosDTO update(Integer id, PedidosDTO pedido) {
        Optional<Pedidos> found = repository.findById(id);

        if (found.isEmpty()) {
            return null;
        }

        pedido.setId(found.get().getId());

        Pedidos savePedido = Pedidos.builder()
                .id(pedido.getId())
                .codigoCliente(pedido.getCodigoCliente())
                .dataPedido(pedido.getDataPedido())
                .valorTotal(pedido.getValorTotal())
                .dataCadastro(found.get().getDataCadastro())
                .build();

        repository.save(savePedido);

        return mapper.toDto(savePedido);
    }

}
