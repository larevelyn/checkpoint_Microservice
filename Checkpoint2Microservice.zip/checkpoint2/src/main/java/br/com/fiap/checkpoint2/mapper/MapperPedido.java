package br.com.fiap.checkpoint2.mapper;

import br.com.fiap.checkpoint2.dto.PedidosDTO;
import br.com.fiap.checkpoint2.mapper.*;
import br.com.fiap.checkpoint2.models.Pedidos;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE,
		nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
		nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)

public interface MapperPedido extends Mapper<Pedidos, PedidosDTO>{

}
