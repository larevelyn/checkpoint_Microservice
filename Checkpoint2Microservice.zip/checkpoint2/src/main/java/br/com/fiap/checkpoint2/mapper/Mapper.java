package br.com.fiap.checkpoint2.mapper;

import java.util.List;

public interface Mapper<E, D> {
	
	D toDto(E entity);

    E toEntity(D dto);

    List<D> toDto(List<E> entities);

    List<D> toDto(Iterable<E> entities);

    List<E> toEntity(List<D> dtos);

    @InheritInverseConfiguration(name = "toDto")
    void fromDto(D dto, @MappingTarget E entity);

}
