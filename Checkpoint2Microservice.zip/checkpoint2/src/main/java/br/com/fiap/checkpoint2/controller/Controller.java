package br.com.fiap.checkpoint2.controller;

import java.net.URI;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.fiap.checkpoint2.dto.PedidosDTO;
import br.com.fiap.checkpoint2.commands.*;

@RequestMapping("pedidos")
@RestController
public class Controller {
	@Autowired
    private Consulta consulta;

    @Autowired
    private Inserir inserir;


    @PostMapping
    @Transactional
    public ResponseEntity<PedidosDTO> create(@RequestBody PedidosDTO pedido, UriComponentsBuilder uriBuilder) {
    	PedidosDTO savePedido = inserir.create(pedido);

        URI uri = uriBuilder.path("/order/{id}").buildAndExpand(savePedido.getId()).toUri();
        return ResponseEntity.created(uri).body(savePedido);
    }

    @GetMapping
    public  ResponseEntity<?> findAll() {
        List<PedidosDTO> response = consulta.findAll();

        if (response.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> detail(@PathVariable(required = true, value = "id") Integer id) {
    	PedidosDTO response = consulta.detail(id);

        if (response == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<?> delete(@PathVariable(required = true, value = "id") Integer id) {
        boolean response = inserir.delete(id);

        if (!response) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity<?> update(@PathVariable(required = true, value = "id") Integer id, @RequestBody PedidosDTO pedido) {
        PedidosDTO response = inserir.update(id, pedido);

        if (response == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(response);
    }


}
