package br.com.fiap.checkpoint2.configurationSwagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

@Configuration
@OpenAPIDefinition(
        servers = {
                @Service(url = "/", description = "Server")
        }
)

public class ConfigSwagger {
	@Bean
    public OpenAPI apiInfo() {
        final var apiName = "Checkpoint2";

        return new OpenAPI()
                .info(new Info().title(apiName).version("1.0.0"));
    }

}
