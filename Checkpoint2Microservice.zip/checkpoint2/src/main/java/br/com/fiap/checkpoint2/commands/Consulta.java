package br.com.fiap.checkpoint2.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.com.fiap.checkpoint2.dto.PedidosDTO;
import br.com.fiap.checkpoint2.mapper.MapperPedido;
import br.com.fiap.checkpoint2.models.Pedidos;
import br.com.fiap.checkpoint2.repository.Repository;


@Service
public class Consulta {

    @Autowired
    Repository repository;

    @Autowired
    MapperPedido mapper;

    public List<PedidosDTO> findAll() {
        List<Pedidos> pedidosFound = repository.findAll();

        List<PedidosDTO> pedidos = new ArrayList<>();

        pedidosFound.stream().forEach(product -> {
        	pedidos.add(mapper.toDto(product));
        });

        return pedidos;
    }

    public PedidosDTO detail(Integer id) {
        Optional<Pedidos> found = repository.findById(id);

        if (found.isEmpty()) {
            return null;
        }

        PedidosDTO pedido = mapper.toDto(found.get());

        return pedido;
    }

}
